/* PDO I Reports service worker: offline app shell and background memo check */
const CACHE='pdo-reports-v1';
const SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png'];
const MT=[
 ['Seminar','ty',/seminar/i],
 ['Webinar / online','ty',/webinar|virtual|online (orientation|session|training|meeting|conference)|zoom|google meet/i],
 ['Training / workshop','ty',/training|workshop|capacity[- ]building|orientation|echo|lac session|learning session|coaching|mentoring/i],
 ['Meeting / conference','ty',/meeting|conference|assembly|forum|summit|dialogue|consultation/i],
 ['Contest / competition','ty',/contest|competition|festival|olympiad|quiz|tilt|pageant|search for/i],
 ['Vacancy / HR','ty',/vacanc|hiring|nosca|reclassification|ranking|appointment|promotion|eligib|\bECP\b|career progression|rpms|ppst/i],
 ['Submission / report','ty',/submission|submit|report|validation|monitoring|inventory|survey|accomplishment|liquidation|deadline/i],
 ['Benefits / payroll','ty',/philhealth|gsis|pag-ibig|salary|allowance|benefit|bonus|payroll|loyalty|cash gift|honorari/i],
 ['Advisory','ty',null],
 ['Principals / School Heads','au',/principal|school head|head teacher|teacher[- ]in[- ]charge|school administration|school governance council|\bSGC\b/i],
 ['Teachers','au',/teacher|teaching personnel|master teacher|adviser|faculty/i],
 ['Bookkeepers / Finance','au',/bookkeeper|disbursing|cashier|accountant|accounting|financial|liquidation|budget|\bMOOE\b|funds?\b|canvass|procurement|supply officer/i],
 ['ADAS / Non-teaching','au',/\bADAS\b|administrative assistant|administrative aide|administrative officer|non-teaching|nurse|clerk|property custodian|registrar/i],
 ['DRRM / Safety','dr',/drrm|disaster|calamit|safety|drill|earthquake|\bfire\b|typhoon|flood|heat|suspension|executive order no\.? ?130|\beo ?130\b|emergency|resilien|evacuat/i],
 ['Sports','sp',/sport|palaro|athlet|games|physical education|basketball|volleyball|chess|marathon|fun run|badminton|track and field/i],
 ['Scouting','sc',/scout|\bBSP\b|\bGSP\b|jamboree|rover/i],
 ['Health / SBFP / WinS','he',/feeding|sbfp|nutrition|\bhealth\b|\bWinS\b|\bWASH\b|hygiene|dental|deworm|vaccin|clinic/i],
 ['Learning / curriculum','le',/literacy|curriculum|assessment|reading|numeracy|\bFELP\b|\bAFBP\b|\bALS\b|learning|\bARAL\b|instruction|alternative learning/i],
 ['Guidance / learner support','le',/learner formation|guidance|counsel|child protection|bullying|mental health|discipline/i],
 ['Supervisors','au',/supervisor|\bPSDS\b|\bEPS\b/i],
 ['Learners','au',/learner(?!\s+formation)|student|pupil/i],
 ['All schools','au',null]
];
const ALLTAGS=MT.map(r=>r[0]),TYPES=MT.filter(r=>r[1]==='ty').map(r=>r[0]);
const tagCls=l=>(MT.find(r=>r[0]===l)||[0,'au'])[1];
function memoTags(m){
 if(Array.isArray(m.tags))return m.tags;
 const t=m.title||'',out=[];
 MT.forEach(r=>{if(r[2]&&r[2].test(t))out.push(r[0])});
 if(!out.some(l=>TYPES.includes(l)))out.unshift('Advisory');
 if(!out.some(l=>!TYPES.includes(l)))out.push('All schools');
 return ALLTAGS.filter(l=>out.includes(l));
}

self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method!=='GET'||u.origin!==location.origin)return;
 e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request).then(r=>r||caches.match('index.html'))));
});
function idbOpen(name){return new Promise((res,rej)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('kv'))r.result.createObjectStore('kv')};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
const idbGet=(name,key)=>idbOpen(name).then(d=>new Promise((res,rej)=>{const g=d.transaction('kv').objectStore('kv').get(key);g.onsuccess=()=>res(g.result);g.onerror=()=>rej(g.error)}));
const idbPut=(name,key,val)=>idbOpen(name).then(d=>new Promise((res,rej)=>{const t=d.transaction('kv','readwrite');t.objectStore('kv').put(val,key);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)}));
const dec=s=>String(s||'').replace(/<[^>]*>/g,' ').replace(/&#(\d+);/g,(m,n)=>String.fromCharCode(n)).replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&nbsp;/g,' ').replace(/\s+/g,' ').trim();
async function getJSON(u){const r=await fetch(u);if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}
async function checkMemos(){
 const app=await idbGet('pdo_reports','db').catch(()=>null);
 const known=new Set(((app&&app.memos)||[]).map(m=>m.id));
 const seen=(await idbGet('pdo_sw','seen').catch(()=>null))||[];seen.forEach(x=>known.add(x));
 const base='https://depedtarlac.com.ph/wp-json/wp/v2/';
 let cat=app&&app.memoCat;
 if(!cat){const c=await getJSON(base+'categories?slug=division-memorandum&_fields=id');cat=c[0].id}
 const posts=await getJSON(base+'posts?categories='+cat+'&per_page=20&_fields=id,date,link,title,excerpt');
 const fresh=posts.filter(p=>!known.has(p.link));
 if(!fresh.length)return 0;
 await idbPut('pdo_sw','seen',seen.concat(fresh.map(p=>p.link)).slice(-300));
 if(known.size<5)return 0;
 for(const p of fresh.slice(0,5)){
  const title=dec(p.title.rendered),subj=dec(p.excerpt&&p.excerpt.rendered)||title;
  const tags=memoTags({title:subj}).join(', ');
  await self.registration.showNotification(title,{body:subj.slice(0,140)+'\n['+tags+']',tag:p.link,data:{url:'./index.html#memos'},icon:'icon-192.png',badge:'icon-192.png'});
 }
 return fresh.length;
}
self.addEventListener('periodicsync',e=>{if(e.tag==='check-memos')e.waitUntil(checkMemos().catch(()=>{}))});
self.addEventListener('message',e=>{if(e.data&&e.data.type==='check-now'){e.waitUntil(checkMemos().then(n=>{if(e.source)e.source.postMessage({type:'checked',n})}).catch(err=>{if(e.source)e.source.postMessage({type:'checked',error:String(err)})}))}});
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{}}catch(x){}e.waitUntil(self.registration.showNotification(d.title||'New Division Memorandum',{body:d.body||'',data:{url:d.url||'./index.html#memos'},icon:'icon-192.png'}))});
self.addEventListener('notificationclick',e=>{
 e.notification.close();
 e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus' in c){c.postMessage({type:'goto',tab:'memos'});return c.focus()}}return self.clients.openWindow((e.notification.data&&e.notification.data.url)||'./index.html#memos')}));
});
