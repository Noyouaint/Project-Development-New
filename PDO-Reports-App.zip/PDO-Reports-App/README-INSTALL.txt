PDO I REPORTS - INSTALL AS A PHONE APP

STEP 1. Put the app on the internet (free, 2 minutes)
  Option A (easiest): go to app.netlify.com/drop, drag this whole folder
  (PDO-Reports-App) onto the page. You get a link like https://xxxx.netlify.app
  Option B: create a GitHub repository, upload these files, turn on Pages.

STEP 2. Open the link on your phone
  Android (Chrome): menu (three dots) > Install app.
  iPhone (Safari): Share button > Add to Home Screen.
  The app now opens like a normal app and works offline.

STEP 3. Notifications for new Division Memoranda
  In the app: School tab > Turn on alerts.
  - Android Chrome: the app can check about twice a day in the background.
  - iPhone: closed apps cannot check in the background. Use STEP 4.

STEP 4 (most reliable, free, works on any phone): memo-watch
  1. Install the free ntfy app (Android or iPhone) and subscribe to a private
     topic name that only you know, e.g. pdo-tarlac-memos-8472.
  2. Create a GitHub repository, upload the memo-watch folder contents
     (the .github/workflows/memo-watch.yml file).
  3. Repository Settings > Secrets and variables > Actions > New secret:
     name NTFY_TOPIC, value = your topic name.
  4. Actions tab > Watch SDO Tarlac memos > Run workflow (first run only saves
     the current list; later runs notify you of each new memo within about 30 minutes).

Your reports stay on your phone. Use Backup regularly.
